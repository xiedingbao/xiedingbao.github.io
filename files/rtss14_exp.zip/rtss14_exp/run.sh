#! /bin/bash
BASE=`pwd`
PROOFDIR=${BASE}/proof

#permit the current user to execute the following files
executable_files="bach_nusmv NuSMV bach_IC3 iimc-hwmcc13 ltl2smv smvtoaig"
for i in ${executable_files}; do
  if [ ! -e ${i} ]; then
    echo "can't find file ${i}"
    exit 1
  fi
  chmod a+x $i
done
 
if [ ! -d ${PROOFDIR} ]; then
  mkdir $PROOFDIR
else
  rm ${PROOFDIR}/*
fi

models="\
water \
tcs \
train \
sample \
motorcade_5 \
motorcade_10 \
motorcade_20 \
motorcade_100 \
motorcade_200"

for i in ${models}; do
  model_path=benchmarks/BACH/${i}.bha;
  option=" -proof=true "
  bound=10
  if [ $i == "tcs" ]; then
    option=" -proof=true -algorithm=primal "
  fi
  START=$(date +%s)
  echo "Doing ${i}... using NuSMV as the LTL checker"
  checkcmd="./bach_nusmv ${option} ${model_path} ${bound}"
  echo ${checkcmd}
  ${checkcmd}
  echo "Done."
  END=$(date +%s)
  DIFF=$(( $END - $START ))
  echo -e "It tooks $DIFF seconds\n"
  
#bach_ic3 is not able to check model motorcade_200 
  if [ $i == "motorcade_200" ]; then 
    continue 
  fi
  START=$(date +%s)
  echo "Doing ${i}... using IC3 based technique"
  checkcmd="./bach_IC3 ${option} ${model_path} ${bound}"
  echo ${checkcmd}
  ${checkcmd}
  echo "Done."
  END=$(date +%s)
  DIFF=$(( $END - $START ))
  echo -e "It tooks $DIFF seconds\n\n"
done
